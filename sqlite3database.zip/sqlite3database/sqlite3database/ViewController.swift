//
//  ViewController.swift
//  sqlite3database
//
//  Created by MACOS on 11/25/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtempid: UITextField!
    
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnselect(_ sender: AnyObject) {
        
        let str = "select * from tblemp";
        let obj = dbclass()
        let arr = obj.getdata(query: str);
        print(arr);
    }
    @IBAction func btndelte(_ sender: AnyObject) {
        
        
        let str = String(format: "delete from tblemp where emp_id =%@",txtempid.text! );
        
        let obj = dbclass();
        
        let  ss = obj.dmloperation(query: str);
        
        if ss == true {
            
            print("recored update ");
        }
        else
        {
            print("not updated ");
            
        }

        
        
    }
    @IBAction func btnupdate(_ sender: AnyObject) {
        
        let str = String(format: "update tblemp set emp_name = %@, emp_add = %@  where emp_id =%@",txtempname.text!,txtempadd.text!,txtempid.text! );
        
        let obj = dbclass();
        
        let  ss = obj.dmloperation(query: str);
        
        if ss == true {
            
            print("recored update ");
        }
        else
        {
            print("not updated ");
            
        }
        
        
    }
    @IBAction func insertclcick(_ sender: AnyObject) {
        
        
        let ss1 = "insert into tblemp(emp_id,emp_name,emp_add)values(\(txtempid.text!),'\(txtempname.text!)','\(txtempadd.text!)')"
        
        print(ss1);
       
        
        let obj = dbclass();
        
      let  ss = obj.dmloperation(query: ss1);
        
        if ss == true {
            
            print("recored inserted");
        }
        else
        {
            print("not insertd");
            
        }
        
    
    }

}

